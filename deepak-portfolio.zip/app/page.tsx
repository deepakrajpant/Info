"use client"

import { ArrowUpIcon, Mail, Phone, Globe } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-teal-400 to-teal-500 dark:from-teal-800 dark:to-teal-900">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-500 to-blue-600 dark:from-blue-700 dark:to-blue-800 py-8 text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-8">Deepak Raj Pant</h1>

          <nav className="flex flex-wrap justify-center gap-2 md:gap-4">
            {[
              { name: "About", icon: "👤" },
              { name: "Education", icon: "🎓" },
              { name: "Certifications", icon: "📜" },
              { name: "Skills", icon: "⚙️" },
              { name: "Experience", icon: "💼" },
              { name: "Projects", icon: "🔍" },
              { name: "Contact", icon: "📧" },
            ].map((item) => (
              <a
                key={item.name}
                href={`#${item.name.toLowerCase()}`}
                className="bg-white/20 hover:bg-white/30 px-4 py-2 rounded-full transition-colors flex items-center gap-2"
              >
                <span>{item.icon}</span>
                <span>{item.name}</span>
              </a>
            ))}
          </nav>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* About Section */}
        <section id="about" className="py-8 scroll-mt-20">
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg p-8 mb-8 animate-fadeIn">
            <h2 className="text-3xl font-bold mb-6 text-purple-700 dark:text-purple-400 border-b-2 border-purple-200 pb-2">
              About Me
            </h2>
            <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
              Motivated and innovative Electrical and Electronics Engineering student with a strong foundation in
              electrical systems, circuit design, and automation. Eager to apply my technical expertise and creative
              ideas to solve complex challenges and contribute to the advancement of technology in the industry.
            </p>
          </div>
        </section>

        {/* Education Section */}
        <section id="education" className="py-8 scroll-mt-20">
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg p-8 mb-8 animate-fadeIn">
            <h2 className="text-3xl font-bold mb-6 text-purple-700 dark:text-purple-400 border-b-2 border-purple-200 pb-2">
              Education
            </h2>
            <div className="space-y-6">
              <div className="bg-slate-100 dark:bg-slate-700 p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-2">Bachelor of Electrical and Electronics Engineering</h3>
                <p className="mb-1">
                  <span className="font-semibold">Institution:</span> Lumbini Engineering College (LEC), Butwal
                </p>
                <p>
                  <span className="font-semibold">Status:</span> Final Year Student | 2025
                </p>
              </div>
              <div className="bg-slate-100 dark:bg-slate-700 p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-2">+2 in Science</h3>
                <p className="mb-1">
                  <span className="font-semibold">Institution:</span> Aishwarya Vidya Niketan (AVN), Dhangadhi
                </p>
                <p>
                  <span className="font-semibold">Graduated:</span> 2021
                </p>
              </div>
              <div className="bg-slate-100 dark:bg-slate-700 p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-2">SEE</h3>
                <p className="mb-1">
                  <span className="font-semibold">Institution:</span> Rastriya Secondary School
                </p>
                <p>
                  <span className="font-semibold">Completed:</span> 2074
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Certifications Section */}
        <section id="certifications" className="py-8 scroll-mt-20">
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg p-8 mb-8 animate-fadeIn">
            <h2 className="text-3xl font-bold mb-6 text-purple-700 dark:text-purple-400 border-b-2 border-purple-200 pb-2">
              Certifications
            </h2>
            <div className="bg-slate-100 dark:bg-slate-700 p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-2">Level 2 Building Electrician</h3>
              <p>
                <span className="font-semibold">Issuing Organization:</span> National Skill Testing Board (NSTB)
              </p>
            </div>
          </div>
        </section>

        {/* Skills Section */}
        <section id="skills" className="py-8 scroll-mt-20">
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg p-8 mb-8 animate-fadeIn">
            <h2 className="text-3xl font-bold mb-6 text-purple-700 dark:text-purple-400 border-b-2 border-purple-200 pb-2">
              Key Skills
            </h2>
            <div className="grid md:grid-cols-2 gap-12">
              <div className="space-y-6">
                <h3 className="text-xl font-bold mb-4">Technical Skills</h3>
                {[
                  "Electrical Engineering",
                  "Circuit Design and Development",
                  "House, Building, and Industrial Wiring",
                  "Microcontroller Programming (Arduino, PIC, etc.)",
                  "Sensors and Modules Integration",
                  "Wireless Control Systems",
                ].map((skill, index) => (
                  <div key={index} className="mb-4">
                    <div className="flex justify-between mb-1">
                      <span className="text-slate-700 dark:text-slate-300">{skill}</span>
                      <span className="text-blue-600 dark:text-blue-400 font-medium">
                        {85 + Math.floor(Math.random() * 15)}%
                      </span>
                    </div>
                    <Progress
                      value={85 + Math.floor(Math.random() * 15)}
                      className="h-2 bg-slate-200 dark:bg-slate-700"
                    />
                  </div>
                ))}
              </div>
              <div className="space-y-6">
                <h3 className="text-xl font-bold mb-4">Software & Development Skills</h3>
                {[
                  "Programming: C, C++",
                  "Programming: HTML, Java, Python",
                  "Lighting and Decoration Design",
                  "Electrical Troubleshooting",
                  "Knowledge of Electronic Components",
                  "Innovative and Creative Solutions",
                ].map((skill, index) => (
                  <div key={index} className="mb-4">
                    <div className="flex justify-between mb-1">
                      <span className="text-slate-700 dark:text-slate-300">{skill}</span>
                      <span className="text-blue-600 dark:text-blue-400 font-medium">
                        {80 + Math.floor(Math.random() * 20)}%
                      </span>
                    </div>
                    <Progress
                      value={80 + Math.floor(Math.random() * 20)}
                      className="h-2 bg-slate-200 dark:bg-slate-700"
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Experience Section */}
        <section id="experience" className="py-8 scroll-mt-20">
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg p-8 mb-8 animate-fadeIn">
            <h2 className="text-3xl font-bold mb-6 text-purple-700 dark:text-purple-400 border-b-2 border-purple-200 pb-2">
              Professional Experience
            </h2>
            <div className="space-y-4">
              {[
                "Conducted house and industrial wiring projects ensuring safety and efficiency.",
                "Designed and implemented small-scale automation systems for homes and businesses.",
                "Diagnosed and resolved electrical faults with a focus on customer satisfaction.",
                "Freelance electrician with expertise in home automation, energy-efficient lighting, and smart sensors.",
              ].map((exp, index) => (
                <div key={index} className="bg-slate-100 dark:bg-slate-700 p-4 rounded-lg">
                  <p className="text-slate-700 dark:text-slate-300">{exp}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Projects Section */}
        <section id="projects" className="py-8 scroll-mt-20">
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg p-8 mb-8 animate-fadeIn">
            <h2 className="text-3xl font-bold mb-6 text-purple-700 dark:text-purple-400 border-b-2 border-purple-200 pb-2">
              Projects
            </h2>
            <div className="grid md:grid-cols-3 gap-6">
              {[
                {
                  title: "Home Automation System",
                  description:
                    "Developed a wireless control system for lighting and appliances using microcontrollers.",
                },
                {
                  title: "Energy-Efficient Lighting",
                  description: "Designed an innovative lighting setup that reduced energy consumption by 20%.",
                },
                {
                  title: "Smart Sensor Integration",
                  description:
                    "Integrated various sensors to automate industrial processes, enhancing safety and productivity.",
                },
              ].map((project, index) => (
                <div
                  key={index}
                  className="bg-slate-100 dark:bg-slate-700 rounded-lg overflow-hidden shadow-md animate-scaleIn"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="h-48 bg-slate-200 dark:bg-slate-600">
                    <img
                      src={`/placeholder.svg?height=200&width=400&text=Project+${index + 1}`}
                      alt={project.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-4">
                    <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                    <p className="text-slate-600 dark:text-slate-300 mb-4">{project.description}</p>
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-8 scroll-mt-20">
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg p-8 mb-8 animate-fadeIn">
            <h2 className="text-3xl font-bold mb-6 text-purple-700 dark:text-purple-400 border-b-2 border-purple-200 pb-2">
              Let's Connect
            </h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <form className="space-y-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                      Your Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      className="w-full px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-slate-700 dark:text-white"
                      placeholder="John Doe"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="email"
                      className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2"
                    >
                      Your Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      className="w-full px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-slate-700 dark:text-white"
                      placeholder="john@example.com"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="message"
                      className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2"
                    >
                      Your Message
                    </label>
                    <textarea
                      id="message"
                      rows={4}
                      className="w-full px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-slate-700 dark:text-white"
                      placeholder="Hello, I'd like to discuss a project..."
                    ></textarea>
                  </div>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">Send Message</Button>
                </form>
              </div>
              <div>
                <div className="bg-slate-100 dark:bg-slate-700 p-6 rounded-lg h-full">
                  <h3 className="text-xl font-bold mb-6">Contact Information</h3>
                  <div className="space-y-6">
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mr-4">
                        <Phone className="text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <p className="text-sm text-slate-500 dark:text-slate-400">Call Now</p>
                        <a
                          href="tel:+9779866157755"
                          className="text-lg font-medium hover:text-blue-600 dark:hover:text-blue-400"
                        >
                          +977 9866157755
                        </a>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mr-4">
                        <Mail className="text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <p className="text-sm text-slate-500 dark:text-slate-400">Send Email</p>
                        <a
                          href="mailto:deepakrajpant978@gmail.com"
                          className="text-lg font-medium hover:text-blue-600 dark:hover:text-blue-400"
                        >
                          deepakrajpant978@gmail.com
                        </a>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mr-4">
                        <Globe className="text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <p className="text-sm text-slate-500 dark:text-slate-400">Visit Website</p>
                        <a
                          href="https://drpant.com.np"
                          className="text-lg font-medium hover:text-blue-600 dark:hover:text-blue-400"
                        >
                          drpant.com.np
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-blue-600 dark:bg-blue-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <h2 className="text-2xl font-bold">Deepak Raj Pant</h2>
              <p className="text-blue-200 mt-2">Electrical and Electronics Engineer</p>
            </div>
            <div className="flex space-x-4">
              {/* Social media icons would go here */}
              <a
                href="#"
                className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
              >
                <span className="sr-only">Facebook</span>
                {/* Facebook icon */}
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
              >
                <span className="sr-only">LinkedIn</span>
                {/* LinkedIn icon */}
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
              >
                <span className="sr-only">GitHub</span>
                {/* GitHub icon */}
              </a>
            </div>
          </div>
          <div className="border-t border-blue-500 mt-8 pt-8 text-center">
            <p className="text-blue-200">© 2025 Deepak Raj Pant. All Rights Reserved.</p>
          </div>
        </div>
      </footer>

      {/* Back to top button */}
      <button
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        className="fixed bottom-6 right-6 w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center shadow-lg hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
        aria-label="Back to top"
      >
        <ArrowUpIcon />
      </button>
    </div>
  )
}

